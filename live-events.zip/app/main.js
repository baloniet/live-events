"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var i18n_providers_1 = require('./i18n-providers');
var app_module_1 = require('./app.module');
i18n_providers_1.getTranslationProviders().then(function (providers) {
    var options = { providers: providers };
    // wait for translation then bootstrap
    platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(app_module_1.AppModule, options);
});
//# sourceMappingURL=main.js.map