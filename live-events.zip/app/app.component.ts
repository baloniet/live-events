import { Component } from '@angular/core';


@Component({
    selector: 'live-events',
    template: '<navbar></navbar>',

})
export class AppComponent { }
