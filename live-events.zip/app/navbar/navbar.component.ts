import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'navbar',
	templateUrl: './app/navbar/navbar.component.html'
})

export class NavbarComponent implements OnInit {

	ngOnInit() { }
}