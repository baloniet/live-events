"use strict";
var testing_1 = require('@angular/core/testing');
var navbar_component_1 = require('./navbar.component');
describe('a navbar component', function () {
    var component;
    // register all needed dependencies
    beforeEach(function () {
        testing_1.TestBed.configureTestingModule({
            providers: [
                navbar_component_1.NavbarComponent
            ]
        });
    });
    // instantiation through framework injection
    /*JL:TODO beforeEach(inject([NavbarComponent], (NavbarComponent) => {
        component = NavbarComponent;
    }));*/
    it('should have an instance', function () {
        expect(component).toBeDefined();
    });
});
//# sourceMappingURL=navbar.component.spec.js.map